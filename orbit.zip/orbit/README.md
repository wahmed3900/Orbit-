# Orbit — multi-model AI chat

A full-stack AI chat app (Node/Express + React/Vite) that lets you switch between **Claude**, **OpenAI** and **Grok (xAI)** in one interface.

## Features
- Switch provider and model from the top bar (grouped by provider)
- Streaming responses with a Stop button
- Web search with source links (Tavily, optional)
- Image upload for vision (paste, drag and drop, or attach — up to 4)
- Image generation ("Create image" mode — OpenAI and Grok)
- Response styles: Regular, Fun, Concise, Expert
- Custom instructions added to every chat
- Voice input (mic) and read-aloud answers
- Chat history saved in the browser: search, rename, delete, export
- Auto-generated chat titles
- Edit a sent message and resend, regenerate the last answer
- Markdown, tables, syntax-highlighted code with copy buttons
- Dark and light themes, mobile layout

## Setup
1. `npm run install:all`
2. Copy `server/.env.example` to `server/.env`, add at least one API key, and set `APP_PASSWORD`
3. `npm run dev`
4. Open http://localhost:5173

Only providers with a key show up in the model menu.

## Production
```
npm run build
npm start
```
The server serves the built client on port 3001.

## Update model names
Model lists live in `server/.env` (`ANTHROPIC_MODELS`, `OPENAI_MODELS`, `XAI_MODELS`). The first one in each list is the default. Change them when providers release new models — no code changes needed.

## Project layout
```
server/
  index.js        API routes: /api/config, /api/chat (SSE), /api/title, /api/imagine
  providers.js    Claude, OpenAI and xAI adapters (xAI uses the OpenAI SDK)
  search.js       Tavily web search
  personas.js     Response style system prompts
client/src/
  App.jsx         State, chat logic, streaming
  components/     Sidebar, Message, Composer, Markdown, SettingsModal, Logo
  lib/            API client and localStorage helpers
```

## Next ideas
- Swap localStorage for MongoDB + user accounts
- Add auth before deploying publicly (the API keys are on your server bill)
- Rate limiting on /api routes
