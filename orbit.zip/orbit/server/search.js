// Web search via Tavily. Returns [] when no key is set.
export async function webSearch(query) {
  if (!process.env.TAVILY_API_KEY) return [];
  const res = await fetch('https://api.tavily.com/search', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ api_key: process.env.TAVILY_API_KEY, query, max_results: 5, search_depth: 'basic' }),
  });
  if (!res.ok) throw new Error(`Search failed (${res.status})`);
  const json = await res.json();
  return (json.results || []).map((r) => ({ title: r.title, url: r.url, content: r.content }));
}

export function sourcesToContext(sources) {
  if (!sources.length) return '';
  const body = sources.map((s, i) => `[${i + 1}] ${s.title}\n${s.url}\n${s.content}`).join('\n\n');
  return `\n\nWeb search results (today is ${new Date().toDateString()}). Use them when relevant and cite with [n]:\n\n${body}`;
}
