import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import crypto from 'node:crypto';
import { availableProviders, streamChat, complete, imagine } from './providers.js';
import { webSearch, sourcesToContext } from './search.js';
import { PERSONAS } from './personas.js';

const app = express();
app.use(cors());
app.use(express.json({ limit: '25mb' }));

// Password lock: set APP_PASSWORD in .env to require it for every API call
const PASSWORD = process.env.APP_PASSWORD || '';
const matches = (given = '') => {
  const a = Buffer.from(given);
  const b = Buffer.from(PASSWORD);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
};
app.use('/api', (req, res, next) => {
  if (!PASSWORD || matches(req.get('x-orbit-password'))) return next();
  res.status(401).json({ error: 'Wrong password' });
});

app.get('/api/config', (_req, res) => {
  res.json({ providers: availableProviders(), search: !!process.env.TAVILY_API_KEY, personas: Object.keys(PERSONAS) });
});

app.post('/api/chat', async (req, res) => {
  const { provider, model, messages = [], persona = 'regular', search = false, customInstructions = '' } = req.body;

  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.flushHeaders();
  const send = (obj) => res.write(`data: ${JSON.stringify(obj)}\n\n`);

  const controller = new AbortController();
  res.on('close', () => controller.abort());

  try {
    let system = PERSONAS[persona] || PERSONAS.regular;
    if (customInstructions.trim()) system += `\n\nUser's custom instructions:\n${customInstructions.trim()}`;

    if (search) {
      const lastUser = [...messages].reverse().find((m) => m.role === 'user');
      send({ type: 'status', text: 'Searching the web' });
      const sources = await webSearch(lastUser?.content || '');
      if (sources.length) send({ type: 'sources', sources: sources.map(({ title, url }) => ({ title, url })) });
      system += sourcesToContext(sources);
    }

    await streamChat({
      provider, model, system, messages, signal: controller.signal,
      onText: (text) => send({ type: 'delta', text }),
    });
    send({ type: 'done' });
  } catch (err) {
    if (!controller.signal.aborted) send({ type: 'error', message: err.message || 'Something went wrong' });
  } finally {
    res.end();
  }
});

app.post('/api/title', async (req, res) => {
  const { provider, model, text } = req.body;
  try {
    const title = await complete({
      provider, model,
      system: 'Write a 3–6 word title for a chat that starts with the message below. Reply with the title only, no quotes or punctuation at the end.',
      prompt: text.slice(0, 2000),
    });
    res.json({ title: title.trim().replace(/^["']|["']$/g, '') });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/imagine', async (req, res) => {
  const { provider, prompt } = req.body;
  try {
    res.json({ image: await imagine({ provider, prompt }) });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Serve the built client in production
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dist = path.join(__dirname, '../client/dist');
app.use(express.static(dist));
app.get(/^(?!\/api).*/, (_req, res) => res.sendFile(path.join(dist, 'index.html')));

const port = process.env.PORT || 3001;
app.listen(port, () => console.log(`Orbit server on http://localhost:${port}`));
