import Anthropic from '@anthropic-ai/sdk';
import OpenAI from 'openai';

const list = (v, fallback) => (v || fallback).split(',').map((s) => s.trim()).filter(Boolean);

export const PROVIDERS = {
  anthropic: {
    label: 'Claude',
    key: () => process.env.ANTHROPIC_API_KEY,
    models: () => list(process.env.ANTHROPIC_MODELS, 'claude-sonnet-5-5,claude-opus-5-5,claude-haiku-5-5'),
    imageModel: () => null,
  },
  openai: {
    label: 'OpenAI',
    key: () => process.env.OPENAI_API_KEY,
    models: () => list(process.env.OPENAI_MODELS, 'gpt-4o,gpt-4o-mini'),
    imageModel: () => process.env.OPENAI_IMAGE_MODEL || 'gpt-image-1',
  },
  xai: {
    label: 'Grok (xAI)',
    key: () => process.env.XAI_API_KEY,
    models: () => list(process.env.XAI_MODELS, 'grok-4,grok-3-mini'),
    imageModel: () => process.env.XAI_IMAGE_MODEL || 'grok-2-image',
  },
};

export function availableProviders() {
  return Object.entries(PROVIDERS)
    .filter(([, p]) => p.key())
    .map(([id, p]) => ({ id, label: p.label, models: p.models(), canImagine: !!p.imageModel() }));
}

function openAICompatible(provider) {
  if (provider === 'xai') return new OpenAI({ apiKey: process.env.XAI_API_KEY, baseURL: 'https://api.x.ai/v1' });
  return new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
}

// Internal message shape: { role: 'user'|'assistant', content: string, images?: [{ mediaType, data }] }
function toAnthropic(messages) {
  return messages.map((m) => {
    if (!m.images?.length) return { role: m.role, content: m.content || ' ' };
    return {
      role: m.role,
      content: [
        ...m.images.map((img) => ({ type: 'image', source: { type: 'base64', media_type: img.mediaType, data: img.data } })),
        { type: 'text', text: m.content || 'Describe this image.' },
      ],
    };
  });
}

function toOpenAI(messages, system) {
  const out = [{ role: 'system', content: system }];
  for (const m of messages) {
    if (!m.images?.length) { out.push({ role: m.role, content: m.content || ' ' }); continue; }
    out.push({
      role: m.role,
      content: [
        { type: 'text', text: m.content || 'Describe this image.' },
        ...m.images.map((img) => ({ type: 'image_url', image_url: { url: `data:${img.mediaType};base64,${img.data}` } })),
      ],
    });
  }
  return out;
}

/** Streams text chunks to onText. Resolves when finished. */
export async function streamChat({ provider, model, system, messages, signal, onText }) {
  if (!PROVIDERS[provider]?.key()) throw new Error(`No API key set for ${provider}`);

  if (provider === 'anthropic') {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const stream = client.messages.stream({ model, max_tokens: 4096, system, messages: toAnthropic(messages) });
    signal.addEventListener('abort', () => stream.abort());
    for await (const event of stream) {
      if (event.type === 'content_block_delta' && event.delta.type === 'text_delta') onText(event.delta.text);
    }
    return;
  }

  const client = openAICompatible(provider);
  const stream = await client.chat.completions.create(
    { model, stream: true, messages: toOpenAI(messages, system) },
    { signal }
  );
  for await (const chunk of stream) {
    const text = chunk.choices?.[0]?.delta?.content;
    if (text) onText(text);
  }
}

/** One-shot completion, used for chat titles. */
export async function complete({ provider, model, system, prompt }) {
  if (provider === 'anthropic') {
    const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
    const res = await client.messages.create({ model, max_tokens: 40, system, messages: [{ role: 'user', content: prompt }] });
    return res.content.map((b) => b.text || '').join('');
  }
  const client = openAICompatible(provider);
  const res = await client.chat.completions.create({
    model,
    max_tokens: 40,
    messages: [{ role: 'system', content: system }, { role: 'user', content: prompt }],
  });
  return res.choices[0]?.message?.content || '';
}

/** Returns a base64 PNG. */
export async function imagine({ provider, prompt }) {
  const p = PROVIDERS[provider];
  if (!p?.key()) throw new Error(`No API key set for ${provider}`);
  if (!p.imageModel()) throw new Error(`${p.label} can't generate images. Switch to OpenAI or Grok.`);
  const client = openAICompatible(provider);
  const params = { model: p.imageModel(), prompt, n: 1 };
  if (provider === 'xai') params.response_format = 'b64_json';
  else params.size = '1024x1024';
  const res = await client.images.generate(params);
  const item = res.data[0];
  if (item.b64_json) return { mediaType: 'image/png', data: item.b64_json };
  // Fallback if a provider returns a URL instead of base64
  const buf = Buffer.from(await (await fetch(item.url)).arrayBuffer());
  return { mediaType: 'image/png', data: buf.toString('base64') };
}
