import { useState } from 'react';
import Logo from './Logo.jsx';

export default function LockScreen({ onUnlock, error }) {
  const [value, setValue] = useState('');
  return (
    <div className="lock">
      <form
        className="lock-card"
        onSubmit={(e) => { e.preventDefault(); if (value) onUnlock(value); }}
      >
        <Logo size={44} />
        <h1>Enter password</h1>
        <input type="password" autoFocus value={value} onChange={(e) => setValue(e.target.value)} placeholder="Password" aria-label="Password" />
        {error && <p className="lock-error">{error}</p>}
        <button className="primary-btn" type="submit" disabled={!value}>Unlock</button>
      </form>
    </div>
  );
}
