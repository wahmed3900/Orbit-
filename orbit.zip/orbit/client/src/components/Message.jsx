import { useState } from 'react';
import { Copy, Check, RotateCcw, Pencil, Volume2, Square, Globe, AlertCircle } from 'lucide-react';
import Markdown from './Markdown.jsx';
import Logo from './Logo.jsx';

export default function Message({ msg, isLast, streaming, status, onRegenerate, onEdit, speakingId, onSpeak }) {
  const [copied, setCopied] = useState(false);
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(msg.content);
  const isUser = msg.role === 'user';
  const pending = isLast && streaming && !isUser;

  const copy = async () => {
    await navigator.clipboard.writeText(msg.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };

  const images = msg.images?.length > 0 && (
    <div className="msg-images">
      {msg.images.map((img, i) => (
        <a key={i} href={`data:${img.mediaType};base64,${img.data}`} download={`orbit-${i + 1}.png`}>
          <img src={`data:${img.mediaType};base64,${img.data}`} alt="" />
        </a>
      ))}
    </div>
  );

  if (isUser) {
    return (
      <div className="msg msg-user">
        {images}
        {editing ? (
          <div className="edit-box">
            <textarea value={draft} onChange={(e) => setDraft(e.target.value)} rows={3} autoFocus />
            <div className="edit-actions">
              <button className="ghost-btn" onClick={() => setEditing(false)}>Cancel</button>
              <button className="primary-btn" onClick={() => { setEditing(false); onEdit(draft); }}>Save and resend</button>
            </div>
          </div>
        ) : (
          msg.content && <div className="bubble">{msg.content}</div>
        )}
        {!editing && !streaming && (
          <div className="msg-actions">
            <button className="icon-btn" title="Copy" onClick={copy}>{copied ? <Check size={15} /> : <Copy size={15} />}</button>
            <button className="icon-btn" title="Edit" onClick={() => { setDraft(msg.content); setEditing(true); }}><Pencil size={15} /></button>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="msg msg-ai">
      <div className="ai-mark"><Logo size={22} spinning={pending} /></div>
      <div className="ai-body">
        {msg.sources?.length > 0 && (
          <div className="sources">
            {msg.sources.map((s, i) => (
              <a key={i} className="source" href={s.url} target="_blank" rel="noreferrer" title={s.title}>
                <Globe size={12} /><span>{i + 1}. {new URL(s.url).hostname.replace('www.', '')}</span>
              </a>
            ))}
          </div>
        )}
        {images}
        {msg.imagesDropped && <p className="muted small-text">Image removed to save browser storage.</p>}
        {msg.content ? <Markdown text={msg.content} /> : pending && <p className="thinking">{status || 'Thinking'}</p>}
        {msg.error && (
          <div className="error-row"><AlertCircle size={16} /> {msg.error}</div>
        )}
        {!pending && (
          <div className="msg-actions">
            {msg.content && <button className="icon-btn" title="Copy" onClick={copy}>{copied ? <Check size={15} /> : <Copy size={15} />}</button>}
            {msg.content && (
              <button className="icon-btn" title={speakingId === msg.id ? 'Stop reading' : 'Read aloud'} onClick={() => onSpeak(msg)}>
                {speakingId === msg.id ? <Square size={14} /> : <Volume2 size={15} />}
              </button>
            )}
            {isLast && <button className="icon-btn" title="Regenerate" onClick={onRegenerate}><RotateCcw size={15} /></button>}
            {msg.model && <span className="model-tag">{msg.model}</span>}
          </div>
        )}
      </div>
    </div>
  );
}
