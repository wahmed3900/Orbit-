import { X, Download } from 'lucide-react';

export default function SettingsModal({ settings, setSettings, onClose, onClearAll, onExport }) {
  const set = (patch) => setSettings((s) => ({ ...s, ...patch }));
  return (
    <div className="modal-scrim" onClick={onClose}>
      <div className="modal" role="dialog" aria-modal="true" aria-labelledby="settings-title" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <h2 id="settings-title">Settings</h2>
          <button className="icon-btn" onClick={onClose} aria-label="Close"><X size={18} /></button>
        </div>

        <label className="field">
          <span>Custom instructions</span>
          <small className="muted">Added to every chat. Tell the AI about you or how to answer.</small>
          <textarea
            rows={5}
            value={settings.customInstructions}
            onChange={(e) => set({ customInstructions: e.target.value })}
            placeholder="I'm a full-stack developer. Prefer short answers with code examples."
          />
        </label>

        <label className="toggle-row">
          <span>
            Read answers aloud automatically
            <small className="muted">Uses your browser's built-in voice.</small>
          </span>
          <input type="checkbox" checked={settings.autoSpeak} onChange={(e) => set({ autoSpeak: e.target.checked })} />
        </label>

        <label className="toggle-row">
          <span>Theme</span>
          <select value={settings.theme} onChange={(e) => set({ theme: e.target.value })}>
            <option value="dark">Dark</option>
            <option value="light">Light</option>
          </select>
        </label>

        <div className="modal-foot">
          <button className="ghost-btn" onClick={onExport}><Download size={15} /> Export chats</button>
          <button className="danger-btn" onClick={() => { if (confirm('Delete all chats? This can’t be undone.')) onClearAll(); }}>Delete all chats</button>
        </div>
      </div>
    </div>
  );
}
