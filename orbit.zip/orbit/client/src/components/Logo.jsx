export default function Logo({ size = 28, spinning = false }) {
  return (
    <svg className={`logo ${spinning ? 'logo-spin' : ''}`} width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <circle cx="16" cy="16" r="9" fill="none" stroke="currentColor" strokeWidth="2.5" />
      <g className="logo-moon">
        <circle cx="25" cy="9" r="3.4" fill="currentColor" />
      </g>
    </svg>
  );
}
