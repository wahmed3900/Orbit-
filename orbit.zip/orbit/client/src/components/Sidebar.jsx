import { useState } from 'react';
import { SquarePen, Search, Trash2, Pencil, Settings, Sun, Moon, X } from 'lucide-react';
import { groupByDate } from '../lib/storage.js';
import Logo from './Logo.jsx';

export default function Sidebar({ chats, activeId, onSelect, onNew, onDelete, onRename, onOpenSettings, theme, onToggleTheme, open, onClose }) {
  const [query, setQuery] = useState('');
  const [renaming, setRenaming] = useState(null);
  const [draft, setDraft] = useState('');

  const q = query.toLowerCase();
  const filtered = chats
    .filter((c) => !q || c.title.toLowerCase().includes(q) || c.messages.some((m) => m.content?.toLowerCase().includes(q)))
    .sort((a, b) => b.updatedAt - a.updatedAt);

  const commit = (id) => { if (draft.trim()) onRename(id, draft.trim()); setRenaming(null); };

  return (
    <>
      <div className={`scrim ${open ? 'show' : ''}`} onClick={onClose} />
      <aside className={`sidebar ${open ? 'open' : ''}`}>
        <div className="side-head">
          <div className="brand"><Logo size={24} /> <span>Orbit</span></div>
          <button className="icon-btn mobile-only" onClick={onClose} aria-label="Close menu"><X size={18} /></button>
        </div>
        <button className="new-chat" onClick={onNew}><SquarePen size={17} /> New chat</button>
        <label className="search-box">
          <Search size={15} />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search chats" />
        </label>

        <nav className="chat-list">
          {filtered.length === 0 && <p className="muted side-empty">{query ? 'No chats match your search.' : 'Your chats will show up here.'}</p>}
          {groupByDate(filtered).map(([label, list]) => (
            <div key={label} className="chat-group">
              <h3>{label}</h3>
              {list.map((c) => (
                <div key={c.id} className={`chat-item ${c.id === activeId ? 'active' : ''}`}>
                  {renaming === c.id ? (
                    <input
                      className="rename-input"
                      autoFocus
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      onBlur={() => commit(c.id)}
                      onKeyDown={(e) => { if (e.key === 'Enter') commit(c.id); if (e.key === 'Escape') setRenaming(null); }}
                    />
                  ) : (
                    <button className="chat-title" onClick={() => onSelect(c.id)} onDoubleClick={() => { setRenaming(c.id); setDraft(c.title); }}>
                      {c.title}
                    </button>
                  )}
                  <div className="chat-item-actions">
                    <button className="icon-btn" title="Rename" onClick={() => { setRenaming(c.id); setDraft(c.title); }}><Pencil size={14} /></button>
                    <button className="icon-btn" title="Delete" onClick={() => onDelete(c.id)}><Trash2 size={14} /></button>
                  </div>
                </div>
              ))}
            </div>
          ))}
        </nav>

        <div className="side-foot">
          <button className="ghost-btn" onClick={onOpenSettings}><Settings size={16} /> Settings</button>
          <button className="icon-btn" onClick={onToggleTheme} title="Switch theme">{theme === 'dark' ? <Sun size={17} /> : <Moon size={17} />}</button>
        </div>
      </aside>
    </>
  );
}
