import { useEffect, useRef, useState } from 'react';
import { ArrowUp, Square, Paperclip, Mic, Globe, ImagePlus, X } from 'lucide-react';
import { fileToImage } from '../lib/storage.js';

const SpeechRecognition = typeof window !== 'undefined' && (window.SpeechRecognition || window.webkitSpeechRecognition);

export default function Composer({ onSend, onStop, streaming, settings, setSettings, canSearch, canImagine, personas }) {
  const [text, setText] = useState('');
  const [images, setImages] = useState([]);
  const [listening, setListening] = useState(false);
  const taRef = useRef(null);
  const fileRef = useRef(null);
  const recRef = useRef(null);
  const imagineMode = settings.mode === 'imagine';

  useEffect(() => {
    const ta = taRef.current;
    if (!ta) return;
    ta.style.height = 'auto';
    ta.style.height = Math.min(ta.scrollHeight, 220) + 'px';
  }, [text]);

  const addFiles = async (files) => {
    const imgs = await Promise.all([...files].filter((f) => f.type.startsWith('image/')).map(fileToImage));
    setImages((prev) => [...prev, ...imgs].slice(0, 4));
  };

  const submit = () => {
    if (streaming || (!text.trim() && !images.length)) return;
    onSend(text.trim(), images);
    setText('');
    setImages([]);
  };

  const toggleMic = () => {
    if (!SpeechRecognition) return alert('Voice input works in Chrome, Edge and Safari.');
    if (listening) { recRef.current?.stop(); return; }
    const rec = new SpeechRecognition();
    rec.interimResults = true;
    rec.continuous = true;
    const start = text ? text + ' ' : '';
    rec.onresult = (e) => {
      const transcript = [...e.results].map((r) => r[0].transcript).join('');
      setText(start + transcript);
    };
    rec.onend = () => setListening(false);
    rec.start();
    recRef.current = rec;
    setListening(true);
  };

  const set = (patch) => setSettings((s) => ({ ...s, ...patch }));

  return (
    <div className="composer-wrap">
      <div
        className={`composer ${imagineMode ? 'is-imagine' : ''}`}
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => { e.preventDefault(); addFiles(e.dataTransfer.files); }}
      >
        {images.length > 0 && (
          <div className="attachments">
            {images.map((img, i) => (
              <div key={i} className="thumb">
                <img src={`data:${img.mediaType};base64,${img.data}`} alt="" />
                <button className="thumb-x" onClick={() => setImages(images.filter((_, j) => j !== i))} aria-label="Remove image"><X size={12} /></button>
              </div>
            ))}
          </div>
        )}
        <textarea
          ref={taRef}
          value={text}
          rows={1}
          placeholder={imagineMode ? 'Describe the image you want' : 'Ask anything'}
          onChange={(e) => setText(e.target.value)}
          onPaste={(e) => e.clipboardData.files.length && addFiles(e.clipboardData.files)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey && !e.nativeEvent.isComposing) { e.preventDefault(); submit(); }
          }}
        />
        <div className="composer-bar">
          <div className="composer-tools">
            <input ref={fileRef} type="file" accept="image/*" multiple hidden onChange={(e) => { addFiles(e.target.files); e.target.value = ''; }} />
            <button className="icon-btn" title="Attach images" onClick={() => fileRef.current.click()} disabled={imagineMode}><Paperclip size={18} /></button>
            {canSearch && (
              <button
                className={`chip ${settings.search && !imagineMode ? 'on' : ''}`}
                onClick={() => set({ search: !settings.search, mode: 'chat' })}
                aria-pressed={settings.search}
              ><Globe size={15} /> Search</button>
            )}
            {canImagine && (
              <button
                className={`chip ${imagineMode ? 'on' : ''}`}
                onClick={() => set({ mode: imagineMode ? 'chat' : 'imagine' })}
                aria-pressed={imagineMode}
              ><ImagePlus size={15} /> Create image</button>
            )}
            {!imagineMode && (
              <select className="chip-select" value={settings.persona} onChange={(e) => set({ persona: e.target.value })} aria-label="Response style">
                {personas.map((p) => <option key={p} value={p}>{p[0].toUpperCase() + p.slice(1)}</option>)}
              </select>
            )}
          </div>
          <div className="composer-tools">
            <button className={`icon-btn ${listening ? 'listening' : ''}`} title={listening ? 'Stop listening' : 'Voice input'} onClick={toggleMic}><Mic size={18} /></button>
            {streaming ? (
              <button className="send-btn" onClick={onStop} aria-label="Stop"><Square size={14} fill="currentColor" /></button>
            ) : (
              <button className="send-btn" onClick={submit} disabled={!text.trim() && !images.length} aria-label="Send"><ArrowUp size={18} /></button>
            )}
          </div>
        </div>
      </div>
      <p className="disclaimer">AI can make mistakes. Check important info.</p>
    </div>
  );
}
