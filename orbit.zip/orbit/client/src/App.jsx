import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Menu, SquarePen } from 'lucide-react';
import Sidebar from './components/Sidebar.jsx';
import Message from './components/Message.jsx';
import Composer from './components/Composer.jsx';
import SettingsModal from './components/SettingsModal.jsx';
import Logo from './components/Logo.jsx';
import { getConfig, postJSON, streamChat, LockedError } from './lib/api.js';
import LockScreen from './components/LockScreen.jsx';
import { load, save, uid } from './lib/storage.js';

const DEFAULT_SETTINGS = {
  provider: '', model: '', persona: 'regular', search: false, mode: 'chat',
  theme: 'dark', customInstructions: '', autoSpeak: false,
};

const SUGGESTIONS = [
  'Explain how WebSockets differ from Server-Sent Events',
  'Write a cold email for an HVAC company',
  'What happened in tech news today?',
  'Roast my JavaScript: var x = x || []',
];

const stripMarkdown = (t) => t.replace(/```[\s\S]*?```/g, ' code block ').replace(/[#*_`>\[\]()-]/g, '');

export default function App() {
  const [config, setConfig] = useState(null);
  const [configError, setConfigError] = useState('');
  const [locked, setLocked] = useState(false);
  const [lockError, setLockError] = useState('');
  const [chats, setChats] = useState(() => load('orbit:chats', []));
  const [activeId, setActiveId] = useState(null);
  const [settings, setSettings] = useState(() => ({ ...DEFAULT_SETTINGS, ...load('orbit:settings', {}) }));
  const [streaming, setStreaming] = useState(false);
  const [status, setStatus] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [showSettings, setShowSettings] = useState(false);
  const [speakingId, setSpeakingId] = useState(null);
  const abortRef = useRef(null);
  const scrollRef = useRef(null);
  const stickToBottom = useRef(true);

  const active = chats.find((c) => c.id === activeId);
  const providers = config?.providers || [];
  const provider = providers.find((p) => p.id === settings.provider) || providers[0];
  const model = provider?.models.includes(settings.model) ? settings.model : provider?.models[0];

  const loadConfig = useCallback((fromUnlock = false) => {
    getConfig()
      .then((c) => { setConfig(c); setLocked(false); setLockError(''); })
      .catch((e) => {
        if (e instanceof LockedError) { setLocked(true); if (fromUnlock) setLockError('That password didn’t work. Try again.'); }
        else setConfigError(e.message);
      });
  }, []);
  useEffect(() => { loadConfig(); }, [loadConfig]);
  useEffect(() => { save('orbit:chats', chats); }, [chats]);
  useEffect(() => { save('orbit:settings', settings); }, [settings]);
  useEffect(() => { document.documentElement.dataset.theme = settings.theme; }, [settings.theme]);

  // Auto-scroll while streaming unless the user scrolled up
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stickToBottom.current) el.scrollTop = el.scrollHeight;
  }, [active?.messages]);

  const updateChat = useCallback((id, fn) => {
    setChats((prev) => prev.map((c) => (c.id === id ? { ...fn(c), updatedAt: Date.now() } : c)));
  }, []);

  const patchLastMessage = (chatId, fn) =>
    updateChat(chatId, (c) => ({ ...c, messages: c.messages.map((m, i) => (i === c.messages.length - 1 ? fn(m) : m)) }));

  const speak = (msg) => {
    speechSynthesis.cancel();
    if (speakingId === msg.id) { setSpeakingId(null); return; }
    const u = new SpeechSynthesisUtterance(stripMarkdown(msg.content));
    u.onend = () => setSpeakingId(null);
    setSpeakingId(msg.id);
    speechSynthesis.speak(u);
  };

  const makeTitle = async (chatId, text) => {
    try {
      const { title } = await postJSON('/api/title', { provider: provider.id, model, text });
      if (title) updateChat(chatId, (c) => ({ ...c, title }));
    } catch { /* keep the fallback title */ }
  };

  /** Runs a model response for the given chat history. */
  const run = async (chatId, history) => {
    const assistant = { id: uid(), role: 'assistant', content: '', model };
    updateChat(chatId, (c) => ({ ...c, messages: [...history, assistant] }));
    setStreaming(true);
    setStatus('');
    stickToBottom.current = true;
    const controller = new AbortController();
    abortRef.current = controller;
    let full = '';

    try {
      await streamChat(
        {
          provider: provider.id, model, persona: settings.persona,
          search: settings.search && config.search,
          customInstructions: settings.customInstructions,
          messages: history.map(({ role, content, images }) => ({ role, content, images })),
        },
        {
          signal: controller.signal,
          onEvent: (ev) => {
            if (ev.type === 'delta') { full += ev.text; patchLastMessage(chatId, (m) => ({ ...m, content: full })); }
            if (ev.type === 'status') setStatus(ev.text);
            if (ev.type === 'sources') patchLastMessage(chatId, (m) => ({ ...m, sources: ev.sources }));
            if (ev.type === 'error') patchLastMessage(chatId, (m) => ({ ...m, error: ev.message }));
          },
        }
      );
      if (settings.autoSpeak && full) speak({ id: assistant.id, content: full });
    } catch (err) {
      if (err.name !== 'AbortError') patchLastMessage(chatId, (m) => ({ ...m, error: err.message }));
    } finally {
      setStreaming(false);
      setStatus('');
      abortRef.current = null;
    }
  };

  const createImage = async (chatId, history, prompt) => {
    const assistant = { id: uid(), role: 'assistant', content: '', model: `${provider.label} image` };
    updateChat(chatId, (c) => ({ ...c, messages: [...history, assistant] }));
    setStreaming(true);
    setStatus('Creating image');
    try {
      const { image } = await postJSON('/api/imagine', { provider: provider.id, prompt });
      patchLastMessage(chatId, (m) => ({ ...m, images: [image], content: `_${prompt}_` }));
    } catch (err) {
      patchLastMessage(chatId, (m) => ({ ...m, error: err.message }));
    } finally {
      setStreaming(false);
      setStatus('');
    }
  };

  const send = (text, images) => {
    if (!provider) return;
    const userMsg = { id: uid(), role: 'user', content: text, images };
    let chatId = activeId;
    let history;
    if (!active) {
      chatId = uid();
      const fallbackTitle = (text || 'Image chat').slice(0, 48);
      setChats((prev) => [{ id: chatId, title: fallbackTitle, createdAt: Date.now(), updatedAt: Date.now(), messages: [] }, ...prev]);
      setActiveId(chatId);
      history = [userMsg];
      if (text) makeTitle(chatId, text);
    } else {
      history = [...active.messages, userMsg];
    }
    if (settings.mode === 'imagine' && provider.canImagine) createImage(chatId, history, text);
    else run(chatId, history);
  };

  const regenerate = () => {
    const msgs = active.messages;
    const history = msgs[msgs.length - 1]?.role === 'assistant' ? msgs.slice(0, -1) : msgs;
    run(active.id, history);
  };

  const editMessage = (index, content) => {
    const history = active.messages.slice(0, index + 1).map((m, i) => (i === index ? { ...m, content } : m));
    run(active.id, history);
  };

  const newChat = () => { abortRef.current?.abort(); setActiveId(null); setSidebarOpen(false); };

  const deleteChat = (id) => {
    setChats((prev) => prev.filter((c) => c.id !== id));
    if (id === activeId) setActiveId(null);
  };

  const exportChats = () => {
    const blob = new Blob([JSON.stringify(chats, null, 2)], { type: 'application/json' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = `orbit-chats-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
  };

  const modelOptions = useMemo(
    () => providers.map((p) => (
      <optgroup key={p.id} label={p.label}>
        {p.models.map((m) => <option key={m} value={`${p.id}::${m}`}>{m}</option>)}
      </optgroup>
    )),
    [providers]
  );

  if (locked) {
    return (
      <LockScreen
        error={lockError}
        onUnlock={(pw) => { localStorage.setItem('orbit:password', pw); loadConfig(true); }}
      />
    );
  }

  return (
    <div className="app">
      <Sidebar
        chats={chats}
        activeId={activeId}
        onSelect={(id) => { setActiveId(id); setSidebarOpen(false); }}
        onNew={newChat}
        onDelete={deleteChat}
        onRename={(id, title) => updateChat(id, (c) => ({ ...c, title }))}
        onOpenSettings={() => setShowSettings(true)}
        theme={settings.theme}
        onToggleTheme={() => setSettings((s) => ({ ...s, theme: s.theme === 'dark' ? 'light' : 'dark' }))}
        open={sidebarOpen}
        onClose={() => setSidebarOpen(false)}
      />

      <main className="main">
        <header className="topbar">
          <button className="icon-btn mobile-only" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu size={20} /></button>
          {provider && (
            <select
              className="model-select"
              value={`${provider.id}::${model}`}
              onChange={(e) => {
                const [p, m] = e.target.value.split('::');
                const next = providers.find((x) => x.id === p);
                setSettings((s) => ({ ...s, provider: p, model: m, mode: next?.canImagine ? s.mode : 'chat' }));
              }}
              aria-label="Model"
            >
              {modelOptions}
            </select>
          )}
          <button className="icon-btn mobile-only" onClick={newChat} aria-label="New chat"><SquarePen size={19} /></button>
        </header>

        <div
          className="scroll"
          ref={scrollRef}
          onScroll={(e) => {
            const el = e.currentTarget;
            stickToBottom.current = el.scrollHeight - el.scrollTop - el.clientHeight < 80;
          }}
        >
          {configError ? (
            <div className="empty"><Logo size={48} /><h1>Can’t reach the server</h1><p className="muted">{configError}</p></div>
          ) : config && providers.length === 0 ? (
            <div className="empty">
              <Logo size={48} />
              <h1>Add an API key to start</h1>
              <p className="muted">Put at least one key in <code>server/.env</code> (Anthropic, OpenAI or xAI), then restart the server.</p>
            </div>
          ) : !active || active.messages.length === 0 ? (
            <div className="empty">
              <Logo size={52} />
              <h1>What do you want to know?</h1>
              <div className="suggestions">
                {SUGGESTIONS.map((s) => <button key={s} onClick={() => send(s, [])}>{s}</button>)}
              </div>
            </div>
          ) : (
            <div className="thread">
              {active.messages.map((m, i) => (
                <Message
                  key={m.id}
                  msg={m}
                  isLast={i === active.messages.length - 1}
                  streaming={streaming}
                  status={status}
                  onRegenerate={regenerate}
                  onEdit={(content) => editMessage(i, content)}
                  speakingId={speakingId}
                  onSpeak={speak}
                />
              ))}
            </div>
          )}
        </div>

        {provider && (
          <Composer
            onSend={send}
            onStop={() => abortRef.current?.abort()}
            streaming={streaming}
            settings={settings}
            setSettings={setSettings}
            canSearch={!!config?.search}
            canImagine={!!provider?.canImagine}
            personas={config?.personas || ['regular']}
          />
        )}
      </main>

      {showSettings && (
        <SettingsModal
          settings={settings}
          setSettings={setSettings}
          onClose={() => setShowSettings(false)}
          onClearAll={() => { setChats([]); setActiveId(null); setShowSettings(false); }}
          onExport={exportChats}
        />
      )}
    </div>
  );
}
